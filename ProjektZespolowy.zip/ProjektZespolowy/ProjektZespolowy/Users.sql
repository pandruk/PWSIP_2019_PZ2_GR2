﻿CREATE TABLE [dbo].[Table]
(
	[UserID] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Username] NVARCHAR(50) NOT NULL, 
    [Password] NVARCHAR(50) NOT NULL, 
    [IsAdmin] BIT NOT NULL
)
