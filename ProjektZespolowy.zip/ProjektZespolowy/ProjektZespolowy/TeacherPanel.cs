﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace ProjektZespolowy
{
    public partial class TeacherPanel : Form
    {
        bool clicked = false;

        int currentUserID = Login.UserID;

        MySqlConnection conn;
        string connection = "Server = 89.39.169.182; Port = 3333; User ID = admin; Password = pwsip-db-cx; Database = DzienniczekDB; Allow User Variables=True";

        public TeacherPanel()
        {
            InitializeComponent();
        }

        private void wylogujToolStripMenuItem_Click(object sender, EventArgs e)
        {
            clicked = true;
            this.Close();
        }

        private void zamknijToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void TeacherPanel_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (clicked == true)
            {
                Login Login = new Login();
                Login.Show();
            }

            else
            {
                Application.Exit();
            }
        }

        private void TeacherPanel_Load(object sender, EventArgs e)
        {
            toolStripStatusLabel2.Text = Convert.ToString(currentUserID);

            //comboBox1.Items.Add
        }

        private void DisplayButton_Click(object sender, EventArgs e)
        {
            try
            {
                string displayQuery = "SELECT SU.subject_name, ST.name, ST.surname, SC.grade " +
                    "FROM Subjects SU, Students ST, Student_Classes SC, Classes C, Teachers T, Users U " +
                    "WHERE ST.student_id = SC.student_id AND SC.class_id = C.class_id " +
                    "AND C.subject_id = SU.subject_id AND C.teacher_id = T.teacher_id " +
                    "AND U.UserID = T.user_id AND T.user_id = " + this.toolStripStatusLabel2.Text;
                conn = new MySqlConnection();
                conn.ConnectionString = connection;
                MySqlCommand displaycomm = new MySqlCommand(displayQuery, conn);
                MySqlDataAdapter Myadapter = new MySqlDataAdapter();
                Myadapter.SelectCommand = displaycomm;
                DataTable dtable = new DataTable();
                Myadapter.Fill(dtable);
                dataGridView1.DataSource = dtable;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void InsertButton_Click(object sender, EventArgs e)
        {
            try
            {
                //conn.ConnectionString = connection;
                //conn = new MySqlConnection();

                string gradestr = GradeTextBox.Text;
                int gradeval = int.Parse(gradestr);
                string nameval = NameTextBox.Text;
                string surnameval = SurnameTextBox.Text;
                string subjectval = SubjectTextBox.Text;

                conn = new MySqlConnection();
                conn.ConnectionString = connection;
                conn.Open();

                //Students.student_id = Student_Classes.student_id
                /*
                string insertQuery = "UPDATE Student_Classes " +
                    "SET grade = @gradeval " +
                    "WHERE grade=(SELECT grade FROM Student_Classes SC, Students ST, Classes C, Subjects S " +
                    "WHERE SC.class_id = C.class_id " +
                    "AND C.subject_id = S.subject_id " +
                    "AND S.subject_name = @subjectval " +
                    "AND SC.student_id = ST.student_id " +
                    "AND ST.name = @nameval " +
                    "AND ST.surname = @surnameval)";
                    */
                /*
                string insertQuery = "update Student_Classes set grade = @gradeval " +
                    "where Student_Classes.class_id = Classes.class_id and Classes.subject_id = Subjects.subject_id and Subjects.subject_name = @subjectval " +
                    "and Student_Classes.student_id = Students.student_id and Students.name = @nameval and Students.surname = @surnameval;";
                    */
                string insertQuery = "";


                MySqlCommand insertcomm = new MySqlCommand(insertQuery, conn);
                

                insertcomm.Parameters.AddWithValue("@gradeval", gradeval);
                insertcomm.Parameters.AddWithValue("@nameval", nameval);
                insertcomm.Parameters.AddWithValue("@surnameval", surnameval);
                insertcomm.Parameters.AddWithValue("@subjectval", subjectval);
                insertcomm.Parameters.AddWithValue("@rola", comboBox1.Text);




                MySqlDataAdapter Myadapter = new MySqlDataAdapter();
                Myadapter.SelectCommand = insertcomm;
                MySqlDataReader MyReader;

                MyReader = insertcomm.ExecuteReader();
                while (MyReader.Read())
                {

                }
                conn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dataGridView1_RowValidated(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void dataGridView1_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellValidated(object sender, DataGridViewCellEventArgs e)
        {
            //do naprawy
            try
            {
                DataTable changes = ((DataTable)dataGridView1.DataSource).GetChanges();
                if (changes != null)
                {
                    MySqlDataAdapter Myadapter = new MySqlDataAdapter();
                    MySqlCommandBuilder mcb = new MySqlCommandBuilder(Myadapter);
                    
                    Myadapter.UpdateCommand = mcb.GetUpdateCommand();
                    Myadapter.Update(changes);
                    ((DataTable)dataGridView1.DataSource).AcceptChanges();

                    MessageBox.Show("Cell Updated");
                    return;
                }


            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        
    }
}
