﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace ProjektZespolowy
{
    public partial class TeacherPanel : Form
    {
        bool clicked = false;

        int currentUserID = Login.UserID;

        MySqlConnection conn;
        string connection = "Server = 89.39.169.182; Port = 3333; User ID = admin; Password = pwsip-db-cx; Database = DzienniczekDB; Allow User Variables=True";

        public TeacherPanel()
        {
            InitializeComponent();
            FillCombo();
            FillComboSubject();
        }

        private void TeacherPanel_Load(object sender, EventArgs e)
        {
            toolStripStatusLabel2.Text = Convert.ToString(currentUserID);

            try
            {
                string nameAndSurnameQuery = "SELECT t_name FROM Teachers WHERE user_id = @UserID";
                string nameAndSurname = null;

                MySqlDataReader readerNameAndSurname = null;

                conn = new MySqlConnection();
                conn.ConnectionString = connection;
                conn.Open();

                MySqlCommand nameAndSurnameComm = new MySqlCommand(nameAndSurnameQuery, conn);
                nameAndSurnameComm.Parameters.AddWithValue("@UserID", currentUserID);

                nameAndSurnameComm.ExecuteNonQuery();

                readerNameAndSurname = nameAndSurnameComm.ExecuteReader();

                while (readerNameAndSurname.Read())
                {
                    nameAndSurname = "(" + (string)readerNameAndSurname["t_name"] + ")";
                }

                conn.Close();

                toolStripStatusLabel3.Text = nameAndSurname;
            }

            catch (Exception)
            {
                toolStripStatusLabel3.Text = "";
            }

        }
        void FillComboSubject()
        {
            string fillQuery = "select SU.subject_name from Users U, Classes C, Teachers T, Subjects SU " +
                " WHERE SU.subject_id = C.subject_id AND C.teacher_id = T.teacher_id " +
                "AND U.UserID = T.user_id AND T.user_id = " + currentUserID;
            conn = new MySqlConnection();
            conn.ConnectionString = connection;
            MySqlCommand fillcomm = new MySqlCommand(fillQuery, conn);
            MySqlDataReader MyReader;
            try
            {
                conn.Open();
                MyReader = fillcomm.ExecuteReader();
                while (MyReader.Read())
                {
                    string combo = MyReader.GetString("subject_name");
                    comboBox4.Items.Add(combo);
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        void FillCombo()
        {
            string fillQuery = "select * from Students S, Student_Classes SC, Users U, Classes C, Teachers T " +
                " WHERE S.student_id = SC.student_id AND SC.class_id = C.class_id AND C.teacher_id = T.teacher_id " +
                "AND U.UserID = T.user_id AND T.user_id = " + currentUserID;
            conn = new MySqlConnection();
            conn.ConnectionString = connection;
            MySqlCommand fillcomm = new MySqlCommand(fillQuery, conn);
            MySqlDataReader MyReader;
            try
            {
                conn.Open();
                MyReader = fillcomm.ExecuteReader();
                while (MyReader.Read())
                {
                    string comboname = MyReader.GetString("st_name");
                    comboBox1.Items.Add(comboname);
                    comboBox5.Items.Add(comboname);
                    comboBox7.Items.Add(comboname);
                    /*
                    string comboname = MyReader.GetString("name");
                    string combosurname = MyReader.GetString("surname");
                    int comboid = MyReader.GetInt32("student_id");
                    comboBox1.Items.Add(comboname);
                    comboBox2.Items.Add(combosurname);
                    comboBox5.Items.Add(comboname);
                    comboBox6.Items.Add(combosurname);
                    comboBox7.Items.Add(comboname);
                    comboBox8.Items.Add(combosurname);
                    */
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void wylogujToolStripMenuItem_Click(object sender, EventArgs e)
        {
            clicked = true;
            this.Close();
        }

        private void zamknijToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void TeacherPanel_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (clicked == true)
            {
                Login Login = new Login();
                Login.Show();
            }

            else
            {
                Application.Exit();
            }
        }


        private void DisplayButton_Click(object sender, EventArgs e)
        {
            try
            {
                string displayQuery = "SELECT SU.subject_name, ST.st_name, SC.grade, SC.grade2, SC.grade3 " +
                    "FROM Subjects SU, Students ST, Student_Classes SC, Classes C, Teachers T, Users U " +
                    "WHERE ST.student_id = SC.student_id AND SC.class_id = C.class_id " +
                    "AND C.subject_id = SU.subject_id AND C.teacher_id = T.teacher_id " +
                    "AND U.UserID = T.user_id AND T.user_id = " + currentUserID;
                conn = new MySqlConnection();
                conn.ConnectionString = connection;
                MySqlCommand displaycomm = new MySqlCommand(displayQuery, conn);
                MySqlDataAdapter Myadapter = new MySqlDataAdapter();
                Myadapter.SelectCommand = displaycomm;
                DataTable dtable = new DataTable();
                Myadapter.Fill(dtable);
                dataGridView1.DataSource = dtable;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void UpdateButton_Click(object sender, EventArgs e)
        {
            try
            {
                int gradeval = int.Parse(comboBox3.SelectedItem.ToString());
                string nameval = comboBox1.SelectedItem.ToString();
                string subjectval = comboBox4.SelectedItem.ToString();
                /*
                int gradeval = int.Parse(comboBox3.SelectedItem.ToString());
                string nameval = comboBox1.SelectedItem.ToString();
                string surnameval = comboBox2.SelectedItem.ToString();
                string subjectval = comboBox4.SelectedItem.ToString();
                */
                conn = new MySqlConnection();
                conn.ConnectionString = connection;
                conn.Open();

                string updateQuery = "UPDATE Student_Classes AS SC " +
                    "INNER JOIN Students S " +
                    "ON SC.student_id = S.student_id " +
                    "INNER JOIN Classes C " +
                    "ON C.class_id = SC.class_id " +
                    "INNER JOIN Subjects SU " +
                    "ON SU.subject_id = C.subject_id " +
                    "SET " + SelectGradeComboBox.SelectedItem.ToString() + " = @gradeval WHERE " +
                    "SU.subject_name = @subjectval AND S.name = @nameval;";

                MySqlCommand insertcomm = new MySqlCommand(updateQuery, conn);
                insertcomm.Parameters.AddWithValue("@gradeval", gradeval);
                insertcomm.Parameters.AddWithValue("@nameval", nameval);
                insertcomm.Parameters.AddWithValue("@subjectval", subjectval);
                insertcomm.Parameters.AddWithValue("@rola", comboBox1.Text);
                /*
                insertcomm.Parameters.AddWithValue("@gradeval", gradeval);
                insertcomm.Parameters.AddWithValue("@nameval", nameval);
                insertcomm.Parameters.AddWithValue("@surnameval", surnameval);
                insertcomm.Parameters.AddWithValue("@subjectval", subjectval);
                insertcomm.Parameters.AddWithValue("@rola", comboBox1.Text);
                */

                insertcomm.ExecuteNonQuery();
                MySqlDataAdapter Myadapter = new MySqlDataAdapter();
                Myadapter.SelectCommand = insertcomm;
                MySqlDataReader MyReader;
                MyReader = insertcomm.ExecuteReader();
                while (MyReader.Read())
                {

                }
                conn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void InsertButton_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_RowValidated(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void dataGridView1_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellValidated(object sender, DataGridViewCellEventArgs e)
        {
            //do naprawy

            /*
            try
            {
                
                DataTable changes = ((DataTable)dataGridView1.DataSource).GetChanges();
                if (changes != null)
                {
                    MySqlDataAdapter Myadapter = new MySqlDataAdapter();
                    MySqlCommandBuilder mcb = new MySqlCommandBuilder(Myadapter);
                    
                    Myadapter.UpdateCommand = mcb.GetUpdateCommand();
                    Myadapter.Update(changes);
                    ((DataTable)dataGridView1.DataSource).AcceptChanges();

                    MessageBox.Show("Cell Updated");
                    return;
                }


            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            */
        }

        private void tabControl1_Click(object sender, EventArgs e)
        {
            
        }



        void GridNotes()
        {
            try
            {
                string displayQuery = "SELECT N.note_id, N.student_id, N.teacher_id, N.note_text FROM Notes N, Teachers T, Users U WHERE " +
                    "U.UserID = T.user_id AND T.user_id = " + currentUserID;
                conn = new MySqlConnection();
                conn.ConnectionString = connection;
                MySqlCommand displaycomm = new MySqlCommand(displayQuery, conn);
                MySqlDataAdapter Myadapter = new MySqlDataAdapter();
                Myadapter.SelectCommand = displaycomm;
                DataTable dtable = new DataTable();
                Myadapter.Fill(dtable);
                dataGridView2.DataSource = dtable;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        void GridAttendance()
        {
            try
            {
                string displayQuery = "SELECT A.attendance_id, A.student_id, A.class_id, A.status, A.date FROM Attendance A, Classes C, Teachers T, Users U WHERE " +
                    "A.class_id = C.class_id AND C.teacher_id = T.teacher_id AND U.UserID = T.user_id AND T.user_id = " + currentUserID;
                conn = new MySqlConnection();
                conn.ConnectionString = connection;
                MySqlCommand displaycomm = new MySqlCommand(displayQuery, conn);
                MySqlDataAdapter Myadapter = new MySqlDataAdapter();
                Myadapter.SelectCommand = displaycomm;
                DataTable dtable = new DataTable();
                Myadapter.Fill(dtable);
                dataGridView3.DataSource = dtable;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        void ComboClasses()
        {
            string fillQuery = "select C.class_name from Classes C, Teachers T, Users U WHERE " +
                "C.teacher_id = T.teacher_id AND U.UserID = T.user_id AND T.user_id = " + currentUserID;
            conn = new MySqlConnection();
            conn.ConnectionString = connection;
            MySqlCommand fillcomm = new MySqlCommand(fillQuery, conn);
            MySqlDataReader MyReader;
            try
            {
                conn.Open();
                MyReader = fillcomm.ExecuteReader();
                while (MyReader.Read())
                {
                    string combo = MyReader.GetString("class_name");
                    comboBox10.Items.Add(combo);
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string nameStudent = comboBox5.SelectedItem.ToString();
                string note = richTextBox1.Text;
                /*
                string nameStudent = comboBox5.SelectedItem.ToString();
                string surnameStudent = comboBox6.SelectedItem.ToString();
                string note = richTextBox1.Text;
                */

                conn = new MySqlConnection();
                conn.ConnectionString = connection;
                conn.Open();

                string insertNote = "insert into Notes(student_id, teacher_id, note_text) " +
                    "VALUES ((SELECT student_id FROM Students WHERE st_name = @namestudent), " +
                    "(SELECT teacher_id FROM Teachers T, Users U WHERE U.UserID = T.user_id AND T.user_id = " + currentUserID +
                    ") , @note);";

                MySqlCommand insertcomm = new MySqlCommand(insertNote, conn);

                insertcomm.Parameters.AddWithValue("@namestudent", nameStudent);
                insertcomm.Parameters.AddWithValue("@note", note);
                /*
                insertcomm.Parameters.AddWithValue("@namestudent", nameStudent);
                insertcomm.Parameters.AddWithValue("@surnamestudent", surnameStudent);
                insertcomm.Parameters.AddWithValue("@note", note);
                */
                insertcomm.ExecuteNonQuery();

                conn.Close();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            GridNotes();
        }

        private void tabControl1_Click_1(object sender, EventArgs e)
        {
            if (GradesTab == tabControl1.SelectedTab)
            {

            }

            if (UwagiTab == tabControl1.SelectedTab)
            {
                comboBox1.Items.Clear();
                //comboBox2.Items.Clear();
                comboBox5.Items.Clear();
                //comboBox6.Items.Clear();
                comboBox7.Items.Clear();
                //comboBox8.Items.Clear();
                FillCombo();
                GridNotes();
            }

            if (ObecnoscTab == tabControl1.SelectedTab)
            {
                comboBox1.Items.Clear();
                //comboBox2.Items.Clear();
                comboBox5.Items.Clear();
                //comboBox6.Items.Clear();
                comboBox7.Items.Clear();
                //comboBox8.Items.Clear();
                comboBox10.Items.Clear();
                FillCombo();
                ComboClasses();
                GridAttendance();
                SetMyCustomFormat();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            GridAttendance();
        }

        public void SetMyCustomFormat()
        {
            dateTimePicker1.Format = DateTimePickerFormat.Custom;
            dateTimePicker1.CustomFormat = "MMMM yyyy";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {

                string nameStudent = comboBox7.SelectedItem.ToString();
                //string surnameStudent = comboBox8.SelectedItem.ToString();
                string className = comboBox10.SelectedItem.ToString();
                string statusName = comboBox9.SelectedItem.ToString();
                string dateVal = Convert.ToString(dateTimePicker1.Value.Date);

                conn = new MySqlConnection();
                conn.ConnectionString = connection;
                conn.Open();

                string insertNote = "insert into Attendance(student_id, class_id, status, date) " +
                    "VALUES ((SELECT student_id FROM Students WHERE st_name = @namestudent), " +
                    "(SELECT C.class_id FROM Classes C, Teachers T, Users U WHERE C.teacher_id = T.teacher_id AND U.UserID = T.user_id AND T.user_id = " + currentUserID +
                    ") , @statusName, @dateVal);";

                MySqlCommand insertcomm = new MySqlCommand(insertNote, conn);

                insertcomm.Parameters.AddWithValue("@namestudent", nameStudent);
                //insertcomm.Parameters.AddWithValue("@surnamestudent", surnameStudent);
                insertcomm.Parameters.AddWithValue("@statusName", statusName);
                insertcomm.Parameters.AddWithValue("@dateVal", dateVal);

                insertcomm.ExecuteNonQuery();

                conn.Close();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
