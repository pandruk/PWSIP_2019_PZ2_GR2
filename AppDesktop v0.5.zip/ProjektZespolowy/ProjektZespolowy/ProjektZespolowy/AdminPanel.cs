﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ProjektZespolowy
{
    public partial class AdminPanel : Form
    {
        bool clicked = false;

        Hash hash;
        MySqlConnection conn;       
        string connection = "Server = 89.39.169.182; Port = 3333; User ID = admin; Password = pwsip-db-cx; Database = DzienniczekDB";

        public AdminPanel()
        {
            InitializeComponent();
        }

        private void AdminPanel_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (clicked == true)
            {
                Login Login = new Login();
                Login.Show();
            }

            else
            {
                Application.Exit();
            }
        }

        private void wylogujToolStripMenuItem_Click(object sender, EventArgs e)
        {
            clicked = true;
            this.Close();
        }

        private void zamknijToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void addUser_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || comboBox1.Text == "")
            {
                MessageBox.Show("Pola nie mogą być puste!");
            }
            else
            {
                MySqlDataReader readerUsername = null;

                conn = new MySqlConnection();
                conn.ConnectionString = connection;
                conn.Open();

                string username = null;
                string checkUsernameQuery = "SELECT Username FROM Users WHERE Username = @Username";
                MySqlCommand usernamecomm = new MySqlCommand(checkUsernameQuery, conn);
                usernamecomm.Parameters.AddWithValue("@Username", textBox1.Text);

                usernamecomm.ExecuteNonQuery();

                readerUsername = usernamecomm.ExecuteReader();

                while (readerUsername.Read())
                {
                    username = (string)readerUsername["Username"];
                }

                conn.Close();

                if (username == textBox1.Text)
                {
                    MessageBox.Show("Taki użytkownik już istnieje!");
                }

                else
                {
                    if (textBox2.Text == textBox3.Text)
                    {
                        try
                        {
                            hash = new Hash();

                            conn = new MySqlConnection();
                            conn.ConnectionString = connection;
                            conn.Open();

                            string insertUserQuery = "INSERT INTO Users (Username, Password, Rola) VALUES (@username, @password, @rola)";

                            MySqlCommand comm = new MySqlCommand(insertUserQuery, conn);
                            comm.Parameters.AddWithValue("@username", textBox1.Text);
                            comm.Parameters.AddWithValue("@password", hash.ToSHA256(textBox2.Text));
                            comm.Parameters.AddWithValue("@rola", comboBox1.Text);

                            comm.ExecuteNonQuery();

                            conn.Close();

                            MessageBox.Show("Użytkownik dodany");
                        }

                        catch (MySqlException ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                    }

                    else
                    {
                        MessageBox.Show("Hasła nie są takie same!");
                    }                   
                }
            }
        }

        private void getUsers_Click(object sender, EventArgs e)
        {
            try
            {
                conn = new MySqlConnection();
                conn.ConnectionString = connection;
                conn.Open();

                string selectUsersQuery = "SELECT * FROM Users;";

                MySqlCommand comm = new MySqlCommand(selectUsersQuery, conn);
  
                MySqlDataAdapter MyAdapter = new MySqlDataAdapter();
                MyAdapter.SelectCommand = comm;
                DataTable dTable = new DataTable();
                MyAdapter.Fill(dTable);
                dataGridView1.DataSource = dTable;

                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
