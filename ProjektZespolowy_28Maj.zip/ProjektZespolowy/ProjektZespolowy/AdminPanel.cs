﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ProjektZespolowy
{
    public partial class AdminPanel : Form
    {
        bool clicked = false;

        Hash hash;
        MySqlConnection conn;       
        string connection = "Server = 89.39.169.182; Port = 3333; User ID = admin; Password = pwsip-db-cx; Database = DzienniczekDB";

        public AdminPanel()
        {
            InitializeComponent();
        }

        private void AdminPanel_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (clicked == true)
            {
                Login Login = new Login();
                Login.Show();
            }

            else
            {
                Application.Exit();
            }
        }

        private void wylogujToolStripMenuItem_Click(object sender, EventArgs e)
        {
            clicked = true;
            this.Close();
        }

        private void zamknijToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void addUser_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || comboBox1.Text == "")
            {
                MessageBox.Show("Pola nie mogą być puste!");
            }
            else
            {
                MySqlDataReader readerUsername = null;

                conn = new MySqlConnection();
                conn.ConnectionString = connection;
                conn.Open();

                string username = null;
                string checkUsernameQuery = "SELECT Username FROM Users WHERE Username = @Username";
                MySqlCommand usernamecomm = new MySqlCommand(checkUsernameQuery, conn);
                usernamecomm.Parameters.AddWithValue("@Username", textBox1.Text);

                usernamecomm.ExecuteNonQuery();

                readerUsername = usernamecomm.ExecuteReader();

                while (readerUsername.Read())
                {
                    username = (string)readerUsername["Username"];
                }

                conn.Close();

                if (username == textBox1.Text)
                {
                    MessageBox.Show("Taki użytkownik już istnieje!");
                }

                else
                {
                    if (textBox2.Text == textBox3.Text)
                    {
                        try
                        {
                            hash = new Hash();

                            conn = new MySqlConnection();
                            conn.ConnectionString = connection;
                            conn.Open();

                            string insertUserQuery = "INSERT INTO Users (Username, Password, Rola) VALUES (@username, @password, @rola)";

                            MySqlCommand comm = new MySqlCommand(insertUserQuery, conn);
                            comm.Parameters.AddWithValue("@username", textBox1.Text);
                            comm.Parameters.AddWithValue("@password", hash.ToSHA256(textBox2.Text));
                            comm.Parameters.AddWithValue("@rola", comboBox1.Text);

                            comm.ExecuteNonQuery();

                            conn.Close();

                            MessageBox.Show("Użytkownik dodany");
                        }

                        catch (MySqlException ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                    }

                    else
                    {
                        MessageBox.Show("Hasła nie są takie same!");
                    }                   
                }
            }
        }

        private void getUsers_Click(object sender, EventArgs e)
        {
            try
            {
                conn = new MySqlConnection();
                conn.ConnectionString = connection;
                conn.Open();

                string selectUsersQuery = "SELECT * FROM Users;";

                MySqlCommand comm = new MySqlCommand(selectUsersQuery, conn);
  
                MySqlDataAdapter MyAdapter = new MySqlDataAdapter();
                MyAdapter.SelectCommand = comm;
                DataTable dTable = new DataTable();
                MyAdapter.Fill(dTable);
                dataGridView1.DataSource = dTable;

                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void tabControl1_Click(object sender, EventArgs e)
        {
            if (tabPage1 == tabControl1.SelectedTab)
            {
                DisplayAllUsers();
            }

            if (tabPage2 == tabControl1.SelectedTab)
            {
                DisplayTeachers();
                DisplayStudents();
                DisplayUsers();

                comboBox2.Items.Clear();
                comboBox3.Items.Clear();
                ComboStudentId();
                ComboTeacherId();
            }

            if (tabPage3 == tabControl1.SelectedTab)
            {
                DisplayClasses();
                DisplayTeachers();

                comboBox4.Items.Clear();
                comboBox5.Items.Clear();
                ComboSubject();
                ComboTeacher_id();
            }

            if (tabPage4 == tabControl1.SelectedTab)
            {
                DisplayStudentClass();
                DisplayStudents();
                DisplayClasses();

                comboBox6.Items.Clear();
                comboBox7.Items.Clear();
                ComboClasses();
                ComboStudent_id();
            }
        }

        void ComboStudent_id()
        {
            string fillQuery = "select * from Students";
            conn = new MySqlConnection();
            conn.ConnectionString = connection;
            MySqlCommand fillcomm = new MySqlCommand(fillQuery, conn);
            MySqlDataReader MyReader;
            try
            {
                conn.Open();
                MyReader = fillcomm.ExecuteReader();
                while (MyReader.Read())
                {
                    int combo = MyReader.GetInt32("student_id");
                    string comboString = combo.ToString();

                    comboBox7.Items.Add(comboString);
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        void ComboClasses()
        {
            string fillQuery = "select * from Classes";
            conn = new MySqlConnection();
            conn.ConnectionString = connection;
            MySqlCommand fillcomm = new MySqlCommand(fillQuery, conn);
            MySqlDataReader MyReader;
            try
            {
                conn.Open();
                MyReader = fillcomm.ExecuteReader();
                while (MyReader.Read())
                {
                    string combo = MyReader.GetString("class_name");
                    comboBox6.Items.Add(combo);
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        void ComboSubject()
        {
            string fillQuery = "select * from Subjects";
            conn = new MySqlConnection();
            conn.ConnectionString = connection;
            MySqlCommand fillcomm = new MySqlCommand(fillQuery, conn);
            MySqlDataReader MyReader;
            try
            {
                conn.Open();
                MyReader = fillcomm.ExecuteReader();
                while (MyReader.Read())
                {
                    string combo = MyReader.GetString("subject_name");
                    comboBox4.Items.Add(combo);
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        void ComboTeacher_id()
        {
            string fillQuery = "select * from Teachers";
            conn = new MySqlConnection();
            conn.ConnectionString = connection;
            MySqlCommand fillcomm = new MySqlCommand(fillQuery, conn);
            MySqlDataReader MyReader;
            try
            {
                conn.Open();
                MyReader = fillcomm.ExecuteReader();
                while (MyReader.Read())
                {
                    int combo = MyReader.GetInt32("teacher_id");
                    string comboString = combo.ToString();
                    
                    comboBox5.Items.Add(comboString);
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        void ComboTeacherId()
        {
            string fillQuery = "select * from Users WHERE Rola='teacher'";
            conn = new MySqlConnection();
            conn.ConnectionString = connection;
            MySqlCommand fillcomm = new MySqlCommand(fillQuery, conn);
            MySqlDataReader MyReader;
            try
            {
                conn.Open();
                MyReader = fillcomm.ExecuteReader();
                while (MyReader.Read())
                {
                    string combo = MyReader.GetString("Username");
                    comboBox3.Items.Add(combo);
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        void ComboStudentId()
        {
            string fillQuery = "select * from Users WHERE Rola='student'";
            conn = new MySqlConnection();
            conn.ConnectionString = connection;
            MySqlCommand fillcomm = new MySqlCommand(fillQuery, conn);
            MySqlDataReader MyReader;
            try
            {
                conn.Open();
                MyReader = fillcomm.ExecuteReader();
                while (MyReader.Read())
                {
                    string combo = MyReader.GetString("Username");
                    comboBox2.Items.Add(combo);
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        void DisplayStudentClass()
        {
            try
            {
                string displayQuery = "SELECT * FROM Student_Classes";
                conn = new MySqlConnection();
                conn.ConnectionString = connection;
                MySqlCommand displaycomm = new MySqlCommand(displayQuery, conn);
                MySqlDataAdapter Myadapter = new MySqlDataAdapter();
                Myadapter.SelectCommand = displaycomm;
                DataTable dtable = new DataTable();
                Myadapter.Fill(dtable);
                dataGridView5.DataSource = dtable;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        void DisplayUsers()
        {
            try
            {
                string displayQuery = "SELECT UserID, Username, Rola FROM Users";
                conn = new MySqlConnection();
                conn.ConnectionString = connection;
                MySqlCommand displaycomm = new MySqlCommand(displayQuery, conn);
                MySqlDataAdapter Myadapter = new MySqlDataAdapter();
                Myadapter.SelectCommand = displaycomm;
                DataTable dtable = new DataTable();
                Myadapter.Fill(dtable);
                dataGridView6.DataSource = dtable;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        void DisplayAllUsers()
        {
            try
            {
                conn = new MySqlConnection();
                conn.ConnectionString = connection;
                conn.Open();

                string selectUsersQuery = "SELECT * FROM Users;";

                MySqlCommand comm = new MySqlCommand(selectUsersQuery, conn);

                MySqlDataAdapter MyAdapter = new MySqlDataAdapter();
                MyAdapter.SelectCommand = comm;
                DataTable dTable = new DataTable();
                MyAdapter.Fill(dTable);
                dataGridView1.DataSource = dTable;

                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        void DisplayClasses()
        {
            try
            {
                string displayQuery = "SELECT * FROM Classes";
                conn = new MySqlConnection();
                conn.ConnectionString = connection;
                MySqlCommand displaycomm = new MySqlCommand(displayQuery, conn);
                MySqlDataAdapter Myadapter = new MySqlDataAdapter();
                Myadapter.SelectCommand = displaycomm;
                DataTable dtable = new DataTable();
                Myadapter.Fill(dtable);
                dataGridView4.DataSource = dtable;
                dataGridView8.DataSource = dtable;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        void DisplayTeachers()
        {
            try
            {
                string displayQuery = "SELECT * FROM Teachers";
                conn = new MySqlConnection();
                conn.ConnectionString = connection;
                MySqlCommand displaycomm = new MySqlCommand(displayQuery, conn);
                MySqlDataAdapter Myadapter = new MySqlDataAdapter();
                Myadapter.SelectCommand = displaycomm;
                DataTable dtable = new DataTable();
                Myadapter.Fill(dtable);
                dataGridView2.DataSource = dtable;
                dataGridView7.DataSource = dtable;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        void DisplayStudents()
        {
            try
            {
                string displayQuery = "SELECT * FROM Students";
                conn = new MySqlConnection();
                conn.ConnectionString = connection;
                MySqlCommand displaycomm = new MySqlCommand(displayQuery, conn);
                MySqlDataAdapter Myadapter = new MySqlDataAdapter();
                Myadapter.SelectCommand = displaycomm;
                DataTable dtable = new DataTable();
                Myadapter.Fill(dtable);
                dataGridView3.DataSource = dtable;
                dataGridView9.DataSource = dtable;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void DisplayButton_Click(object sender, EventArgs e)
        {
            DisplayStudents();
        }

        private void InsertStudent_Click(object sender, EventArgs e)
        {
            try
            {
                string nameStudent = textBox4.Text;
                string surnameStudent = textBox5.Text;
                string userName = comboBox2.SelectedItem.ToString();

                conn = new MySqlConnection();
                conn.ConnectionString = connection;
                conn.Open();

                string insertStudent = "insert into Students(UserID, name, surname) " +
                    "VALUES ((SELECT UserID FROM Users WHERE Username = @userName), @namestudent, @surnamestudent);";

                MySqlCommand insertcomm = new MySqlCommand(insertStudent, conn);

                insertcomm.Parameters.AddWithValue("@namestudent", nameStudent);
                insertcomm.Parameters.AddWithValue("@surnamestudent", surnameStudent);
                insertcomm.Parameters.AddWithValue("@userName", userName);

                insertcomm.ExecuteNonQuery();

                conn.Close();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void InsertTeacher_Click(object sender, EventArgs e)
        {
            try
            {
                string nameTeacher = textBox6.Text;
                string surnameTeacher = textBox7.Text;
                string userName = comboBox3.SelectedItem.ToString();

                conn = new MySqlConnection();
                conn.ConnectionString = connection;
                conn.Open();

                string insertTeacher = "insert into Teachers(user_id, teacher_name, teacher_surname) " +
                    "VALUES ((SELECT UserID FROM Users WHERE Username = @userName), @namesteacher, @surnameteacher);";

                MySqlCommand insertcomm = new MySqlCommand(insertTeacher, conn);

                insertcomm.Parameters.AddWithValue("@namesteacher", nameTeacher);
                insertcomm.Parameters.AddWithValue("@surnameteacher", surnameTeacher);
                insertcomm.Parameters.AddWithValue("@userName", userName);

                insertcomm.ExecuteNonQuery();

                conn.Close();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void ShowTeachers_Click(object sender, EventArgs e)
        {
            DisplayTeachers();
        }

        private void InsertClass_Click(object sender, EventArgs e)
        {
            try
            {
                string className = textBox8.Text;
                string subjectName = comboBox4.SelectedItem.ToString();
                string teacherId = comboBox5.SelectedItem.ToString();

                conn = new MySqlConnection();
                conn.ConnectionString = connection;
                conn.Open();

                string insertClass = "insert into Classes(subject_id, teacher_id, class_name) " +
                    "VALUES ((SELECT subject_id FROM Subjects WHERE subject_name = @subjectName), @teacherId, @className);";

                MySqlCommand insertcomm = new MySqlCommand(insertClass, conn);

                insertcomm.Parameters.AddWithValue("@className", className);
                insertcomm.Parameters.AddWithValue("@subjectName", subjectName);
                insertcomm.Parameters.AddWithValue("@teacherId", teacherId);

                insertcomm.ExecuteNonQuery();

                conn.Close();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void DisplayClassesButton_Click(object sender, EventArgs e)
        {
            DisplayClasses();
        }

        private void AddStudentToClassButton_Click(object sender, EventArgs e)
        {
            try
            {
                string className = comboBox6.SelectedItem.ToString();
                string studentId = comboBox7.SelectedItem.ToString();

                conn = new MySqlConnection();
                conn.ConnectionString = connection;
                conn.Open();

                string insertClass = "insert into Student_Classes(class_id, student_id) " +
                    "VALUES ((SELECT class_id FROM Classes WHERE class_name = @className), @studentId);";

                MySqlCommand insertcomm = new MySqlCommand(insertClass, conn);

                insertcomm.Parameters.AddWithValue("@className", className);
                insertcomm.Parameters.AddWithValue("@studentId", studentId);

                insertcomm.ExecuteNonQuery();

                conn.Close();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void DisplayStudentClassButton_Click(object sender, EventArgs e)
        {
            DisplayStudentClass();
        }
    }
}
