﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace ProjektZespolowy
{
    public partial class TeacherPanel : Form
    {
        bool clicked = false;

        int currentUserID = Login.UserID;

        MySqlConnection conn;
        string connection = "Server = 89.39.169.182; Port = 3333; User ID = admin; Password = pwsip-db-cx; Database = DzienniczekDB; Allow User Variables=True";

        public TeacherPanel()
        {
            InitializeComponent();
            FillCombo();
            FillComboSubject();
        }

        private void TeacherPanel_Load(object sender, EventArgs e)
        {
            toolStripStatusLabel2.Text = Convert.ToString(currentUserID);

        }
        void FillComboSubject()
        {
            string fillQuery = "select SU.subject_name from Users U, Classes C, Teachers T, Subjects SU " +
                " WHERE SU.subject_id = C.subject_id AND C.teacher_id = T.teacher_id " +
                "AND U.UserID = T.user_id AND T.user_id = " + currentUserID;
            conn = new MySqlConnection();
            conn.ConnectionString = connection;
            MySqlCommand fillcomm = new MySqlCommand(fillQuery, conn);
            MySqlDataReader MyReader;
            try
            {
                conn.Open();
                MyReader = fillcomm.ExecuteReader();
                while (MyReader.Read())
                {
                    string combo = MyReader.GetString("subject_name");
                    comboBox4.Items.Add(combo);
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        void FillCombo()
        {
            string fillQuery = "select * from Students S, Student_Classes SC, Users U, Classes C, Teachers T " +
                " WHERE S.student_id = SC.student_id AND SC.class_id = C.class_id AND C.teacher_id = T.teacher_id " +
                "AND U.UserID = T.user_id AND T.user_id = " + currentUserID;
            conn = new MySqlConnection();
            conn.ConnectionString = connection;
            MySqlCommand fillcomm = new MySqlCommand(fillQuery, conn);
            MySqlDataReader MyReader;
            try
            {
                conn.Open();
                MyReader = fillcomm.ExecuteReader();
                while (MyReader.Read())
                {
                    string comboname = MyReader.GetString("name");
                    string combosurname = MyReader.GetString("surname");
                    int comboid = MyReader.GetInt32("student_id");
                    comboBox1.Items.Add(comboname);
                    comboBox2.Items.Add(combosurname);
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void wylogujToolStripMenuItem_Click(object sender, EventArgs e)
        {
            clicked = true;
            this.Close();
        }

        private void zamknijToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void TeacherPanel_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (clicked == true)
            {
                Login Login = new Login();
                Login.Show();
            }

            else
            {
                Application.Exit();
            }
        }


        private void DisplayButton_Click(object sender, EventArgs e)
        {
            try
            {
                string displayQuery = "SELECT SU.subject_name, ST.name, ST.surname, SC.grade " +
                    "FROM Subjects SU, Students ST, Student_Classes SC, Classes C, Teachers T, Users U " +
                    "WHERE ST.student_id = SC.student_id AND SC.class_id = C.class_id " +
                    "AND C.subject_id = SU.subject_id AND C.teacher_id = T.teacher_id " +
                    "AND U.UserID = T.user_id AND T.user_id = " + currentUserID;
                conn = new MySqlConnection();
                conn.ConnectionString = connection;
                MySqlCommand displaycomm = new MySqlCommand(displayQuery, conn);
                MySqlDataAdapter Myadapter = new MySqlDataAdapter();
                Myadapter.SelectCommand = displaycomm;
                DataTable dtable = new DataTable();
                Myadapter.Fill(dtable);
                dataGridView1.DataSource = dtable;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void UpdateButton_Click(object sender, EventArgs e)
        {
            try
            {
                
                int gradeval = int.Parse(comboBox3.SelectedItem.ToString());
                string nameval = comboBox1.SelectedItem.ToString();
                string surnameval = comboBox2.SelectedItem.ToString();
                string subjectval = comboBox4.SelectedItem.ToString();
                conn = new MySqlConnection();
                conn.ConnectionString = connection;
                conn.Open();

                string updateQuery = "UPDATE Student_Classes AS SC " +
                    "INNER JOIN Students S " +
                    "ON SC.student_id = S.student_id " +
                    "INNER JOIN Classes C " +
                    "ON C.class_id = SC.class_id " +
                    "INNER JOIN Subjects SU " +
                    "ON SU.subject_id = C.subject_id " +
                    "SET grade = @gradeval WHERE " +
                    "SU.subject_name = @subjectval AND S.name = @nameval and S.surname = @surnameval;";

                MySqlCommand insertcomm = new MySqlCommand(updateQuery, conn);
                insertcomm.Parameters.AddWithValue("@gradeval", gradeval);
                insertcomm.Parameters.AddWithValue("@nameval", nameval);
                insertcomm.Parameters.AddWithValue("@surnameval", surnameval);
                insertcomm.Parameters.AddWithValue("@subjectval", subjectval);
                insertcomm.Parameters.AddWithValue("@rola", comboBox1.Text);

                insertcomm.ExecuteNonQuery();
                MySqlDataAdapter Myadapter = new MySqlDataAdapter();
                Myadapter.SelectCommand = insertcomm;
                MySqlDataReader MyReader;
                MyReader = insertcomm.ExecuteReader();
                while (MyReader.Read())
                {

                }
                conn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void InsertButton_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_RowValidated(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void dataGridView1_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellValidated(object sender, DataGridViewCellEventArgs e)
        {
            //do naprawy

            /*
            try
            {
                
                DataTable changes = ((DataTable)dataGridView1.DataSource).GetChanges();
                if (changes != null)
                {
                    MySqlDataAdapter Myadapter = new MySqlDataAdapter();
                    MySqlCommandBuilder mcb = new MySqlCommandBuilder(Myadapter);
                    
                    Myadapter.UpdateCommand = mcb.GetUpdateCommand();
                    Myadapter.Update(changes);
                    ((DataTable)dataGridView1.DataSource).AcceptChanges();

                    MessageBox.Show("Cell Updated");
                    return;
                }


            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            */
        }
    }
}
