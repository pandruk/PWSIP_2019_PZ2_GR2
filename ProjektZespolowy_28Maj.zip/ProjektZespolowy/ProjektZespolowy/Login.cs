﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ProjektZespolowy
{
    public partial class Login : Form
    {
        Hash hash;
        MySqlConnection conn;
        string connection = "Server = 89.39.169.182; Port = 3333; User ID = admin; Password = pwsip-db-cx; Database = DzienniczekDB";

        public static int UserID;

        public Login()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dbConnect();
            UserID = 0;
        }

        private void zaloguj_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "")
            {
                MessageBox.Show("Pola nie mogą być puste!");
            }
            else
            {
                MySqlDataReader readerUsername = null;
                MySqlDataReader readerPassword = null;
                MySqlDataReader readerRola = null;
                MySqlDataReader readerUserID = null;

                conn = new MySqlConnection();
                conn.ConnectionString = connection;
                conn.Open();

                string username = null;
                string checkUsernameQuery = "SELECT Username FROM Users WHERE Username = @Username";
                MySqlCommand usernamecomm = new MySqlCommand(checkUsernameQuery, conn);
                usernamecomm.Parameters.AddWithValue("@Username", textBox1.Text);

                usernamecomm.ExecuteNonQuery();

                readerUsername = usernamecomm.ExecuteReader();

                while (readerUsername.Read())
                {
                   username = (string)readerUsername["Username"];
                }

                conn.Close();

                if (username == textBox1.Text)
                {
                    hash = new Hash();

                    conn = new MySqlConnection();
                    conn.ConnectionString = connection;
                    conn.Open();

                    string password = null;
                    string checkPasswordQuery = "SELECT Password FROM Users WHERE Username = @Username";
                    MySqlCommand passcomm = new MySqlCommand(checkPasswordQuery, conn);
                    passcomm.Parameters.AddWithValue("@Username", textBox1.Text);

                    passcomm.ExecuteNonQuery();

                    readerPassword = passcomm.ExecuteReader();                   

                    while (readerPassword.Read())
                    {
                        password = (string)readerPassword["Password"];
                    }

                    conn.Close();

                    if (password == hash.ToSHA256(textBox2.Text))
                    {
                        conn = new MySqlConnection();
                        conn.ConnectionString = connection;
                        conn.Open();

                        string rola = null;
                        string checkRolaQuery = "SELECT Rola FROM Users WHERE Username = @Username";
                        MySqlCommand rolacomm = new MySqlCommand(checkRolaQuery, conn);
                        rolacomm.Parameters.AddWithValue("@Username", textBox1.Text);

                        rolacomm.ExecuteNonQuery();

                        readerRola = rolacomm.ExecuteReader();

                        while (readerRola.Read())
                        {
                            rola = (string)readerRola["Rola"];
                        }

                        conn.Close();

                        conn = new MySqlConnection();
                        conn.ConnectionString = connection;
                        conn.Open();

                        string checkUserIDQuery = "SELECT UserID FROM Users WHERE Username = @Username";
                        MySqlCommand useridcomm = new MySqlCommand(checkUserIDQuery, conn);
                        useridcomm.Parameters.AddWithValue("@Username", textBox1.Text);

                        useridcomm.ExecuteNonQuery();

                        readerUserID = useridcomm.ExecuteReader();

                        while (readerUserID.Read())
                        {
                            UserID = (int)readerUserID["UserID"];
                        }

                        if (rola == "admin")
                        {
                            AdminPanel adminPanel = new AdminPanel();
                            adminPanel.Show();
                        }

                        if (rola == "teacher")
                        {                          
                            TeacherPanel teacherPanel = new TeacherPanel();
                            teacherPanel.Show();
                        }

                        if (rola == "student")
                        {
                            ParentPanel parentPanel = new ParentPanel();
                            parentPanel.Show();
                        }

                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Login lub hasło niepoprawne");
                    }
                }

                else
                {
                    MessageBox.Show("Login lub hasło niepoprawne");
                }
            }
        }

        private void zamknij_Click(object sender, EventArgs e)
        {
            if (conn.State == ConnectionState.Open)
            {
                conn.Close();
            }          
            
            Application.Exit();
        }

        private void dbConnect()
        {
            try
            {
                conn = new MySqlConnection();
                conn.ConnectionString = connection;
                conn.Open();

                if (conn.State == ConnectionState.Open)
                {
                    label3.Text = "Status: Online";
                }

                conn.Close();
            }
            catch
            {
                DialogResult dialogResult = MessageBox.Show("Nie udało się połączyć z bazą danych. Ponowić próbę?", "Error", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    dbConnect();
                }
                else if (dialogResult == DialogResult.No)
                {
                    Close();
                }

                label3.Text = "Status: Offline";
            }
        }

        /* Służy do stworzenia pierwszego admina

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                hash = new Hash();

                conn = new MySqlConnection();
                conn.ConnectionString = connection;
                conn.Open();

                string insertQuery = "INSERT INTO Users (UserID, Username, Password, Rola) VALUES (@id, @username, @password, @rola)";
                MySqlCommand comm = new MySqlCommand(insertQuery, conn);
                comm.Parameters.AddWithValue("@id", "1");
                comm.Parameters.AddWithValue("@username", "admin");
                comm.Parameters.AddWithValue("@password", hash.ToSHA256("adminpass"));
                comm.Parameters.AddWithValue("@rola", "admin");

                comm.ExecuteNonQuery();

                conn.Close();
            }

            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        
        */
    }
}
