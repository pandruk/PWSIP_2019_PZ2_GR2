﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ProjektZespolowy
{
    public partial class ParentPanel : Form
    {
        bool clicked = false;

        int currentUserID = Login.UserID;

        MySqlConnection conn;
        string connection = "Server = 89.39.169.182; Port = 3333; User ID = admin; Password = pwsip-db-cx; Database = DzienniczekDB";

        public ParentPanel()
        {
            InitializeComponent();
        }

        private void wylogujToolStripMenuItem_Click(object sender, EventArgs e)
        {
            clicked = true;
            this.Close();
        }

        private void zamknijToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void ParentPanel_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (clicked == true)
            {
                Login Login = new Login();
                Login.Show();
            }

            else
            {
                Application.Exit();
            }
        }

        private void ParentPanel_Load(object sender, EventArgs e)
        {
            toolStripStatusLabel2.Text = Convert.ToString(currentUserID);

            try
            {
                string nameAndSurnameQuery = "SELECT name, surname FROM Students WHERE UserID = @UserID";
                string nameAndSurname = null;

                MySqlDataReader readerNameAndSurname = null;

                conn = new MySqlConnection();
                conn.ConnectionString = connection;
                conn.Open();

                MySqlCommand nameAndSurnameComm = new MySqlCommand(nameAndSurnameQuery, conn);
                nameAndSurnameComm.Parameters.AddWithValue("@UserID", currentUserID);

                nameAndSurnameComm.ExecuteNonQuery();

                readerNameAndSurname = nameAndSurnameComm.ExecuteReader();

                while (readerNameAndSurname.Read())
                {
                    nameAndSurname = "(" + (string)readerNameAndSurname["name"] + " " + (string)readerNameAndSurname["surname"] + ")";
                } 

                conn.Close();

                toolStripStatusLabel3.Text = nameAndSurname;
            }

            catch (Exception)
            {
                toolStripStatusLabel3.Text = "";
            }
        }

        private void DisplayButton_Click(object sender, EventArgs e)
        {
            try
            {
                string displayQuery = "SELECT SU.subject_name, ST.name, ST.surname, SC.grade AS Grade1, SC.grade2 AS Grade2, SC.grade3 AS Grade3 " +
                    "FROM Subjects SU, Students ST, Student_Classes SC, Classes C, Teachers T, Users U " +
                    "WHERE ST.student_id = SC.student_id AND SC.class_id = C.class_id " +
                    "AND C.subject_id = SU.subject_id AND C.teacher_id = T.teacher_id " +
                    "AND U.UserID = ST.UserID AND ST.UserID = " + currentUserID;
                conn = new MySqlConnection();
                conn.ConnectionString = connection;
                MySqlCommand displaycomm = new MySqlCommand(displayQuery, conn);
                MySqlDataAdapter Myadapter = new MySqlDataAdapter();
                Myadapter.SelectCommand = displaycomm;
                DataTable dtable = new DataTable();
                Myadapter.Fill(dtable);
                dataGridView1.DataSource = dtable;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            GridNotes();
        }

        void GridNotes()
        {
            try
            {
                string displayQuery = "SELECT N.note_id, N.student_id, N.teacher_id, N.note_text FROM Notes N, Students S, Users U WHERE " +
                    "U.UserID = S.UserID AND S.UserID = " + currentUserID;
                conn = new MySqlConnection();
                conn.ConnectionString = connection;
                MySqlCommand displaycomm = new MySqlCommand(displayQuery, conn);
                MySqlDataAdapter Myadapter = new MySqlDataAdapter();
                Myadapter.SelectCommand = displaycomm;
                DataTable dtable = new DataTable();
                Myadapter.Fill(dtable);
                dataGridView2.DataSource = dtable;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string displayQuery = "SELECT A.student_id, C.class_name, A.status, A.date FROM Attendance A, Students S, Classes C, Users U WHERE " +
                    "C.class_id = A.class_id AND A.student_id = S.student_id AND U.UserID = S.UserID AND S.UserID = " + currentUserID;
                conn = new MySqlConnection();
                conn.ConnectionString = connection;
                MySqlCommand displaycomm = new MySqlCommand(displayQuery, conn);
                MySqlDataAdapter Myadapter = new MySqlDataAdapter();
                Myadapter.SelectCommand = displaycomm;
                DataTable dtable = new DataTable();
                Myadapter.Fill(dtable);
                dataGridView3.DataSource = dtable;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
